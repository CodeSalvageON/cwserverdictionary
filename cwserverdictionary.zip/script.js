var visitedForm = 0;

function redirectForm(){
  if (visitedForm == 0){
    var iframe = document.getElementById('iframe');
    var add = document.getElementById('add_to_dictionary');

    iframe.innerHTML = '<iframe src="newword.html" width="600" height="100%" frameBorder="0"></iframe>';
    add.innerText = ' (Look at the dictionary)';

    visitedForm = 1;
  }
  else if (visitedForm == 1){
    var iframe = document.getElementById('iframe');
    var add = document.getElementById('add_to_dictionary');

    iframe.innerHTML = '<iframe src="context.php" width="600" height="100%" frameBorder="0"></iframe>';
    add.innerText = ' (Add to the dictionary)';

    visitedForm = 0;
  }
}
<!DOCTYPE html>
<html>
 <head>
  <title>null</title>
  <link href="context.css" rel="stylesheet" type="text/css"/>
 </head>
 <body>
  <?php
  $wordlist = glob('words/*');

  foreach($wordlist as $wordname){
    echo "<h2><a href='".$wordname."'>".$wordname."</a></h2>";
  }
  ?>
 </body>
</html>
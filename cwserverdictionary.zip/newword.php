<html>
 <head>
  <title>Null</title>
 </head>
  <body>
   <?php
   $word_file_location = './words/'.$_POST['word_name'].'.html';

   if (file_exists($word_file_location) == true){
     $file_open_word = fopen($word_file_location, 'a+');
     fwrite($file_open_word, '<br/><html><head><meta http-equiv="Content-Security-Policy" content="script-src https://code.jquery.com "self";"><link href="https://cwserverdictionary.codesalvageon.repl.co/context.css" rel="stylesheet" type="text/css"/><title>null</title></head><body><h1 id="word-name">'.$_POST['word_name'].'</h1><h2 id="word-def">'.$_POST['def'].'</h2><script src="https://cwserverdictionary.codesalvageon.repl.co/pub_scripts/'.$_POST['word_name'].'.js"></script></body></html>');
     fclose($file_open_word);
   }
   else{
     $file_open_word = fopen($word_file_location, 'a+');
     fwrite($file_open_word, '<html><head><meta http-equiv="Content-Security-Policy" content="script-src https://code.jquery.com "self";"><link href="https://cwserverdictionary.codesalvageon.repl.co/context.css" rel="stylesheet" type="text/css"/><title>null</title></head><body><h1 id="word-name">'.$_POST['word_name'].'</h1><h2 id="word-def">'.$_POST['def'].'</h2><script src="https://cwserverdictionary.codesalvageon.repl.co/pub_scripts/'.$_POST['word_name'].'.js"></script></body></html>');
     fclose($file_open_word);
     $open_pub_scripts = fopen('./pub_scripts/'.$_POST['word_name'].'.js', 'a+');
     fwrite($open_pub_scripts, 'var word-name = document.getElementById("word-name"); var def = document.getElementById("def"); word-name.innerText = "'.$_POST['word_name'].'"; def.innerText = "'.$_POST['def'].'";');
   }
   ?>
   <script>location = 'context.php';</script>
  </body>
</html>
<html>
  <head>
    <title>CW Discord Dictionary</title>
    <link href="style.css" rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:wght@300&display=swap" rel="stylesheet">
  </head>
  <body>
     <center><h1>CW Discord Server Dictionary</h1></center>
     <center><h2>Discord server: <a href="https://discord.gg/nUDjbph">Here</a></h2></center>
     <center><h2>Created by Shadow Trooper aka Origami Yoda</h2></center>
     <h1>Words <div class="fake_anchor" onclick="redirectForm()" id="add_to_dictionary"> (Add to the dictionary)</div></h1>
     <div id="iframe"><iframe src="context.php" width="600" height="100%" frameBorder="0"></iframe></div>
     <img src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.gameinformer.com%2Fs3%2Ffiles%2Fstyles%2Fbody_default%2Fs3%2Flegacy-images%2Fimagefeed%2FDiscord%2520Partnering%2520With%2520Esports%2520Teams%2520For%2520Official%2520Channels%2Fdiscord_2D00_logo_2D00_610.png&f=1&nofb=1" width="60" height="50" id="discord" onclick="https://discord.gg/VmkUuJ5"/>
     <script src="script.js"></script>
  </body>
</html>
var word-name = document.getElementById("word-name"); var def = document.getElementById("def"); word-name.innerText = "Narci"; def.innerText = "the biggest boomer you will ever find.
";